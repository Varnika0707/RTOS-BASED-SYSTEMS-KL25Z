
/*----------------------------------------------------------------------------
    Given code for Embedded Systems Lab 6
    
    This project illustrates the use of 
      - threads
      - event flags
      - a message queue

    The behaviour is: 
        - the green LED can be turned on or off using command entered on a terminal 
          emulator (see lab sheet) and send over the USB link
        - if the command are entered in the wrong order, the system enters an
          error state: the red LED flashes
        - to exit from the error state the 'reset' command must be entered
        - the system is initialised in the error state
        
    There are three threads
       t_serial: waits for input from the terminal; sends message to t_greenLED
       t_greenLED: turns the green LED on and off on receipt of the message. Enters
         an error state when the message is not appropriate
       t_redLED: flashes the red on and off when an error state is signalled by the
         t_greenLED
    
    Message queue: 
       * Message are put in the queue t_serial
       * Messages are read from the queue by t_greenLED

    Signal using event flags
       * A flag is set by t_greenLED
       * The thread t_redLED waits on the flag

 *---------------------------------------------------------------------------*/
 
#include "cmsis_os2.h"
#include "string.h"

#include <MKL25Z4.h>
#include <stdbool.h>
#include "gpio.h"
#include "serialPort.h"

#define RESET_EVT (1)
osEventFlagsId_t errorFlags ;       // id of the event flags
osMessageQueueId_t controlMsgQ ;    // id for the message queue


osThreadId_t t_readInput;        // id of thread to read the data from the terminal emulator
osThreadId_t t_controlLEDs;      // id of thread to control the Green and Red LEDs 

//void ReadInput ();     //declaration of ReadInput function
//void ChangeLEDs ();    //declaration of ChangeLEDs function


/*-----------------------------------------------------------------------------------------------
 *   
 *                        BASIC PART STARTS
 *   
 *------------------------------------------------------------------------------------------------*/



// LED states
#define REDON (0)
#define GREENON (1)

enum controlMsg_t {faster, slower} ;  // type for the messages

//float ONTIME[8] = {0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0};//Same ONTIME for both LEDs


void ControlLEDs (void *arg) 
{
		int NEWONTIME;//UPDATED DELAY WHENVER THE USER ENTERS IN THE TERMINAL EMULATOR
		int ONTIME = 4000;//INITIAL TIME PERIOD WHEN THE SYSTEM STARTS
		int MINONTIME = 500;//MINIMUM ON TIME FOR BOTH LEDs IS 0.5 SECONDS i.e., 500ms
		int MAXONTIME = 4000;//The maximum On time for both LEDs is 4 seconds i.e, 4000ms
		int ledState = GREENON ;//Initial state
	  redLEDOnOff(LED_ON);
    //redLEDOnOff(LED_ON);
    enum controlMsg_t msg ;
    osStatus_t status ;   // returned by message queue get
		while (1) 
		{
			
			// wait for message from queue
      status = osMessageQueueGet(controlMsgQ, &msg, NULL, ONTIME);//waits for ONTIME=4000 ms for the user to enter 
			
					
			switch(ledState)
			{
				case REDON:
					
				if(status==osOK)//Check if the message is recieved or not
					{
							if(msg == faster)
							{
									if(ONTIME<=MAXONTIME && ONTIME>MINONTIME)
									{ 
										NEWONTIME = ONTIME - 500;//updating the new ONTIME if faster is given as input
										ONTIME = NEWONTIME;
									}
									else if(ONTIME == MINONTIME)
									{
										ONTIME = MAXONTIME;
									}
							
							}
							else if(msg == slower)
							{
								if(ONTIME<MAXONTIME && ONTIME>=MINONTIME)
									{ 
										NEWONTIME = ONTIME + 500;//updating the new ONTIME is slower is given as an input
										ONTIME = NEWONTIME;
									}
									else if(ONTIME == MAXONTIME)
									{
										ONTIME = MINONTIME;
									}
							
							}
		
					}
					
				if(status == osErrorTimeout)
				{
						
					greenLEDOnOff(LED_OFF);
					redLEDOnOff(LED_ON);
					ledState=GREENON;
				
				}
				
			
				break;
					
				case GREENON:
					
				if(status==osOK)//Check if the message is recieved or not
					{
							if(msg == faster)
							{
									if(ONTIME<=MAXONTIME && ONTIME>MINONTIME)
									{ 
										NEWONTIME = ONTIME - 500;//updating the new ONTIME if faster is given as input
										ONTIME = NEWONTIME;
									}
									else if(ONTIME == MINONTIME)
									{
										ONTIME = MAXONTIME;
									}
							
							}
							else if(msg == slower)
							{
								if(ONTIME<MAXONTIME && ONTIME>=MINONTIME)
									{		
										NEWONTIME = ONTIME + 500;//updating the new ONTIME is slower is given as an input
										ONTIME = NEWONTIME;
									}
									else if(ONTIME == MAXONTIME)
									{
										ONTIME = MINONTIME;
									}
							  
							}
		
					}
					if(status == osErrorTimeout)
					{
						redLEDOnOff(LED_OFF);
						greenLEDOnOff(LED_ON);
						ledState=REDON;
					}
						
				break;
			
			  
			}
			
		}      
	}




char prompt[] = "Command: faster / slower" ; //const
char empty[] = "" ;                          //const

void ReadInput(void *args){
	  char response[8] ;  // buffer for response string
    enum controlMsg_t msg ;
    bool valid ;
    while (1) {
        //sendMsg(empty, CRLF) ;
        sendMsg(prompt, NOLINE) ;
        readLine(response, 6) ;  // 
  			valid = true ;
        if (strcmp(response, "faster") == 0) {
            msg = faster ;
        } else if (strcmp(response, "slower") == 0) {
            msg = slower ;
        }
        else valid = false ;
        
        if (valid) {
            osMessageQueuePut(controlMsgQ, &msg, 0, NULL);  // Send Message
        } else {
            sendMsg(response, NOLINE) ;
            sendMsg(" input not recognised ", CRLF) ;
        }
    }
}

/*---------------------------------------------------------------------------------------------------------
*
*															          BASIC PART ENDS
*
-----------------------------------------------------------------------------------------------------------*/



















/*--------------------------------------------------------------
 *   Thread t_redLED
 *       Flash Red LED to show an error
 *       States are: ERRORON, ERROROFF and NOERROR
 *       A signal is set to change the error status
 *          - LED off when no error
 *          - LED flashes when there is an error
 *--------------------------------------------------------------*/
/*
osThreadId_t t_redLED;        //id of thread to flash red led 

// Red LED states
#define ERRORON (0)
#define ERROROFF (1)
#define NOERROR (2)
#define ERRORFLASH (400)

void redLEDThread (void *arg) {
    int redState = ERRORON ;
    redLEDOnOff(LED_ON);
    uint32_t flags ;                // returned by osEventFlagWait
    uint32_t delay = ERRORFLASH ;   // delay used in the wait - varies (osEventFlagWait will complete either when the signal arrives or when the delay is up)

    while (1) {
        // wait for a signal or timeout
        flags = osEventFlagsWait (errorFlags, MASK(RESET_EVT), osFlagsWaitAny, delay);
        
        // interpret state machine
        switch (redState) {
            case ERRORON:   // error state - flashing, currently on
                redLEDOnOff(LED_OFF);
                if (flags == osFlagsErrorTimeout) {  // timeout continue flashing           
                    redState = ERROROFF ;
                } else {                             // signal - move to no error state
                    redState = NOERROR ;
                    delay = osWaitForever ;
                }
                break ;

            case ERROROFF:   // error state - flashing, currently off
                if (flags == osFlagsErrorTimeout) {  // timeout continue flashing
                    redLEDOnOff(LED_ON);
                    redState = ERRORON ;
                } else {                             // signal - move to no error state
                    redState = NOERROR ;
                    delay = osWaitForever ;
                }
                break ;
                
            case NOERROR:                            // no error - react on signal
                delay = ERRORFLASH ;
                redState = ERRORON ;
                redLEDOnOff(LED_ON) ;            
                break ;
        }
    }
}

*/


/*--------------------------------------------------------------
 *   Thread t_greenLED
 *      Set the green on and off on receipt of message
 *      Messages: on, off and reset (uses an enum)
 *      Acceptable message
 *         - in on state expect off message
 *         - in off state expect on message
 *         - in error state expect reset message
 *      If 'wrong' message received 
 *          - Move to error state
 *          - Signal red LED to flash
 *          - Reset message returns LED to on state 
 *--------------------------------------------------------------*/
 /*
osThreadId_t t_greenLED;      //id of thread to toggle green led 

// Green LED states
#define GREENON (0)
#define GREENOFF (1)
#define GERROR (2)

enum controlMsg_t {on, off, reset} ;  // type for the messages

void greenLEDThread (void *arg) {
    int ledState = GERROR ;
    greenLEDOnOff(LED_OFF);
    enum controlMsg_t msg ;
    osStatus_t status ;   // returned by message queue get
    while (1) {
        // wait for message from queue
        status = osMessageQueueGet(controlMsgQ, &msg, NULL, osWaitForever);
        if (status == osOK) {
            switch (ledState) {
                case GREENON:
                    if (msg == off) {           // expected message
                        greenLEDOnOff(LED_OFF);
                        ledState = GREENOFF ; 
                    }
                    else {                      // unexpected - go to error
                        // signal red thread                        
                        osEventFlagsSet(errorFlags, MASK(RESET_EVT)) ;
                        greenLEDOnOff(LED_OFF);
                        ledState = GERROR ;
                    }
                    break ;
                    
                case GREENOFF:      
                    if (msg == on) {            // expected message
                        greenLEDOnOff(LED_ON);
                        ledState = GREENON ; 
                    }
                    else {                      // unexpected - go to error
                        // signal red thread                        
                        osEventFlagsSet(errorFlags, MASK(RESET_EVT)) ;
                        ledState = GERROR ;
                    }
                    break ;
                    
                case GERROR: 
                    if (msg == reset) {         // expected message
                        // signal red thread to elave error state  
                        osEventFlagsSet(errorFlags, MASK(RESET_EVT)) ;
                        greenLEDOnOff(LED_ON);
                        ledState = GREENON ;
                    }
                    // ignore other messages - already in error state
                    break ;
                }
        }
    }
}
*/



/*------------------------------------------------------------
 *  Thread t_command
 *      Request user command
 *      
 *
 *------------------------------------------------------------*/
/*
osThreadId_t t_command;        // id of thread to receive command 

// const // char prompt[] = "Command: on / off / reset>" ;
// const // char empty[] = "" ;

void commandThread (void *arg) {
    char response[6] ;  // buffer for response string
    enum controlMsg_t msg ;
    bool valid ;
    while (1) {
        //sendMsg(empty, CRLF) ;
        sendMsg(prompt, NOLINE) ;
        readLine(response, 5) ;  // 
  			valid = true ;
        if (strcmp(response, "on") == 0) {
            msg = on ;
        } else if (strcmp(response, "off") == 0) {
            msg = off ;
        } else if (strcmp(response, "reset") == 0) {
            msg = reset ;
        } else valid = false ;
        
        if (valid) {
            osMessageQueuePut(controlMsgQ, &msg, 0, NULL);  // Send Message
        } else {
            sendMsg(response, NOLINE) ;
            sendMsg(" not recognised", CRLF) ;
        }
    }
}
*/





/*----------------------------------------------------------------------------
 * Application main
 *   Initialise I/O
 *   Initialise kernel
 *   Create threads
 *   Start kernel
 *---------------------------------------------------------------------------*/

int main (void) { 
    
    // System Initialization
    SystemCoreClockUpdate();

    // Initialise peripherals
    configureGPIOoutput();
    //configureGPIOinput();
    init_UART0(115200) ;

    // Initialize CMSIS-RTOS
    osKernelInitialize();
    
    // Create event flags
    errorFlags = osEventFlagsNew(NULL);
    
    // create message queue
   controlMsgQ = osMessageQueueNew(2, sizeof(enum controlMsg_t), NULL) ;

    // initialise serial port 
    initSerialPort() ;

   //ljnCreate threads
		
		t_controlLEDs= osThreadNew(ControlLEDs, NULL, NULL);
		t_readInput= osThreadNew(ReadInput, NULL, NULL);
   //t_redLED = osThreadNew(redLEDThread, NULL, NULL); 
   //t_greenLED = osThreadNew(greenLEDThread, NULL, NULL);
   //t_command = osThreadNew(commandThread, NULL, NULL); 
    
    osKernelStart();    // Start thread execution - DOES NOT RETURN(unless something is wrong)
    for (;;) {}         // Only executed when an error occurs
}
