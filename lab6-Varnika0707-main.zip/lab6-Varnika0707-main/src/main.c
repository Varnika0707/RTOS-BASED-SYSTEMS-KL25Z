
/*----------------------------------------------------------------------------------------------------------------
                                         Embedded Systems Lab 6
 *---------------------------------------------------------------------------------------------------------------*/
 
#include "cmsis_os2.h"
#include "string.h"

#include <MKL25Z4.h>
#include <stdbool.h>
#include "gpio.h"
#include "serialPort.h"

#define RESET_EVT (1)
osEventFlagsId_t errorFlags ;       // id of the event flags
osMessageQueueId_t controlMsgQ ;    // id for the message queue


osThreadId_t t_readInput;        // id of thread to recieve data from the terminal emulator entered by the user
osThreadId_t t_controlLEDs;      // id of thread to control the Green and Red LEDs 


/*----------------------------------------------------------------------------------------------------------------
 *   
 *                                        BASIC PART 
 *   
 *----------------------------------------------------------------------------------------------------------------*/



// LED states
#define REDON (0)
#define GREENON (1)

enum controlMsg_t {faster, slower} ;  // type for the messages

void ControlLEDs (void *arg) //This function controls the LEDs
{
    int NEWONTIME;//Updated ONTIME whenever the user types in the terminal emulator
    int ONTIME = 4000;//This is the initial time period when then system starts i.e., 4sec = 4000ms
    int MINONTIME = 500;//this is the minimum ONTIME for both LEDs i.e., red and green. 0.5sec = 500ms
    int MAXONTIME = 4000;//this is the maximum ONTIME for both LEDs i.e., red and green. 4sec = 4000ms.
	
    int ledState = GREENON ;//Initial state of the system
    redLEDOnOff(LED_ON);//The red LED is ON initially
 
    enum controlMsg_t msg ;
	
    osStatus_t status ;   // This defines the status and error codes that are returned by osMessageQueueGet
	
    while (1) 
    {
			
          // wait for message from queue
          status = osMessageQueueGet(controlMsgQ, &msg, NULL, ONTIME);//waits for ONTIME=4000 ms for the user to enter 
			
					
			switch(ledState)
			{
				case REDON:
					
				if(status==osOK)//Checks if any message has been put into the queue. This means that the operation was successfully completed.
				{//enter if any message recieved
					if(msg == faster)//Checks if the recieved message is faster 
					{//enter if message recieved is faster
								
						if(ONTIME<=MAXONTIME && ONTIME>MINONTIME)//Checks If the ONTIME is between MAXONTIME and MINOTIME
						{//Enter if the condition holds true
										
							NEWONTIME = ONTIME - 500;//Subtracting 500ms from the ONTIME
							ONTIME = NEWONTIME;//Updating the ONTIME
										
						}//End of if statement
									
						else if(ONTIME == MINONTIME)//Checks if the ONTIME has the value 500
						{//Enter if the value of ONTIME is 500
										
							ONTIME = MAXONTIME;//Update the ONTIME
										
						}//End of else if statement
							
					}//End of If statement
							
					else if(msg == slower)//Checks if the messae recieved it slower
					{//enter if message recieved is slower
								
						if(ONTIME<MAXONTIME && ONTIME>=MINONTIME)//Checks If the ONTIME is between MAXONTIME and MINOTIME
						{//Enter if the condition holds true
										
							NEWONTIME = ONTIME + 500;//Adding 500ms to the ONTIME 
							ONTIME = NEWONTIME;//Updating the ONTIME
										
						}//end of if statement
									
						else if(ONTIME == MAXONTIME)
						{//Enter if the value of ONTIME is 4000
										
							ONTIME = MINONTIME;//update the ONTIME
										
						}//end of else if statement
							
					}//end of else if statement
		
				}//end of if statement
					
				if(status == osErrorTimeout)//Checks if the status value is osErrorTimeout which means that the operation was not completed within the timeout period
				{//enter the if statement if the condition holds true
						
					greenLEDOnOff(LED_OFF);//Turn off green LED
					redLEDOnOff(LED_ON);//Turn on red LED
					ledState=GREENON;//Change the LED state
				
				}//end of if statement
				
			
				break;
					
				case GREENON:
					
				if(status==osOK)//Check if the message has been put in the queue. The operation was completed successfully.
				{//enter if the condition is true
						
					if(msg == faster)//checks if the message recieved is faster
					{//enter if statement if te=he contion is true
								
						if(ONTIME<=MAXONTIME && ONTIME>MINONTIME)//checks whether ONTIME is between MAXONTIME and MINONTIME 
						{//enter if statement is the ondition is true
										
							NEWONTIME = ONTIME - 500;//updating the new ONTIME if faster is given as input
							ONTIME = NEWONTIME;//Update the ONTIME
										
						}//end of if statement
									
						else if(ONTIME == MINONTIME)//Checks if the ONTIME value is the MINONTIME
					        {//Enter else if statement if the condition is true
										
							ONTIME = MAXONTIME;//Update the ONTIME
										
						}//End of else if statement
							
					}//end of if statement
					else if(msg == slower)//checks if the message recieved is slower
					{//Enter if the condition holds true
								
						if(ONTIME<MAXONTIME && ONTIME>=MINONTIME)
						{//Enter if the condition is true
										
							NEWONTIME = ONTIME + 500;//Adding 500ms to the ONTIME if the message is slower
							ONTIME = NEWONTIME;//update the ONTIME
										
						}//end of if statement
									
						else if(ONTIME == MAXONTIME)
						{//enter if the condition is true
										
							ONTIME = MINONTIME;//Update the ONTIME
										
						}//end of else if statement
							  
					}//end of else if statement
		
				}//End of if statement
					
				if(status == osErrorTimeout)//Checks if the status is osErrorTimeout which means that the operation is not completed within the timeout period
				{//Enter if the condition holds true
						
					redLEDOnOff(LED_OFF);//Turn red led off
					greenLEDOnOff(LED_ON);//Turn Green led on
					ledState=REDON;//change the led state to REDON
						
				}//End of if statement
						
				break;
			
			  
			}//End of switch
			
    }//end of while loop
		
}//end of "ControlLEDs" function




char prompt[] = "Command: faster / slower" ; //const
char empty[] = "" ;                          //const

void ReadInput(void *args){//This function reads the input from the user
	
	  char response[8] ;  // buffer for response string
    enum controlMsg_t msg ;
    bool valid ;
	
    while (1) {
        
        sendMsg(prompt, NOLINE) ;
        readLine(response, 6) ;  // 
  			valid = true ;
			
        if (strcmp(response, "faster") == 0) {//start of if statement
            msg = faster ;
        }//end of if statement
				
				else if (strcmp(response, "slower") == 0) {//start of else  if statement
            msg = slower ;
        }//end of else if staement
				
        else {//start of else statement
					valid = false ;
				}//end of else statement
        
        if (valid) {//start of if statement
            osMessageQueuePut(controlMsgQ, &msg, 0, NULL);  // Send Message
        }//end of if statement
				
				else {//start of else statement
            sendMsg(response, NOLINE) ;
            sendMsg(" input not recognised ", CRLF) ;//If the user types anything other than "faster" or "slower" then, show "input not recognised"
        }//end of else statement
    }
}



/*----------------------------------------------------------------------------
 * Application main
 *   Initialise I/O
 *   Initialise kernel
 *   Create threads
 *   Start kernel
 *---------------------------------------------------------------------------*/

int main (void) { //main function starts
    
    // System Initialization
    SystemCoreClockUpdate();

    // Initialise peripherals
    configureGPIOoutput();
    //configureGPIOinput();
    init_UART0(115200) ;

    // Initialize CMSIS-RTOS
    osKernelInitialize();
    
    // Create event flags
    errorFlags = osEventFlagsNew(NULL);
    
    // create message queue
   controlMsgQ = osMessageQueueNew(2, sizeof(enum controlMsg_t), NULL) ;

    // initialise serial port 
    initSerialPort() ;

    //Create threads
		t_controlLEDs= osThreadNew(ControlLEDs, NULL, NULL);
		t_readInput= osThreadNew(ReadInput, NULL, NULL);
   
    osKernelStart();    // Start thread execution - DOES NOT RETURN(unless something is wrong)
    for (;;) {}         // Only executed when an error occurs
}
